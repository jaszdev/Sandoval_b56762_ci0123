#include <condition_variable>
#include <semaphore.h>

class Monitor
{
    public: 
        int N; // calles
        int K; // cantidad de carros para dejar pasar 

        Monitor(int n, int k)
        {
            N = n;
            K = k;

            carrosPorCalle = (int *)calloc(N, sizeof(int));
            for(int i = 0; i < N; i++) carrosPorCalle[i] = 0;

            sem_init(&semaforo, 0, 1);
        }

        ~Monitor()
        {
            free(carrosPorCalle);
        }

        
        
        void NuevoCarro(int calle) // metodo para que el carro avise que llego
        {
            sem_wait(&semaforo);
            carrosPorCalle[calle]++;
            sem_post(&semaforo);
        }

        bool DejarPasar() 
        {
            return carrosEnEspera >= K;
        };



    private:
        sem_t semaforo;
        std::condition_variable self[5];
        int * carrosPorCalle; // arreglo de enteros para contar cuantos carros hay en cada calle
        int carrosEnEspera; // valor para comparar con k
};