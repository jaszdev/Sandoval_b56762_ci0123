#include <stdio.h>
#include <semaphore.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <time.h>  

struct carroArgs
{
    sem_t * recodoA;
    sem_t * recodoB;
    sem_t * semX;
    sem_t * semY;
    int * carrosRecodoA;
    int * carrosRecodoB;
};


void rutinaCarro(int id, int calle, carroArgs * args)
{
    time_t t;
    srand((unsigned) time(&t) + id * 5);

    int tiempoEsperaInicial = 1 + rand() % 5;
    sleep(tiempoEsperaInicial); // tiempo de espera, de 1 a 6 segundos
    printf("Carro %d: Empezando a andar. Espere %d segundos\n", id, tiempoEsperaInicial);
    // salir
    sleep(1 + rand() % 1); // tiempo de espera para llegar a primera interseccion, de 1 a 2 segundos

    // pasar por primera interseccion
    sem_t * semPriInt = calle == 0 ? args->semX : args->semY; // semX o semY

    sem_wait(semPriInt);
    char nombreInt = calle == 0 ? 'X' : 'Y';
    printf("Carro %d: Cruzando interseccion %c\n", id, nombreInt);
    sleep(1 + rand() % 1); // tiempo de espera interseccion, de 1 a 2 segundos
    sem_post(semPriInt);

    sleep(1 + rand() % 2); // tiempo de espera para llegar a recodo, de 1 a 3 segundos

    // cruzar recodo
    sem_t * semRecodo = calle == 0 ? args->recodoA : args->recodoB;

    sem_wait(semRecodo);
    sleep(1); // tiempo para cruzar recodo
    char calleNombre = calle == 0 ? 'A' : 'B';
    printf("Carro %d: Cruze recodo en calle %c.\n", id, calleNombre);
    sem_post(semRecodo);

    //cruzar segunda interseccion
    sleep(1 + rand() % 1); // tiempo de espera para llegar a segunda interseccion, de 1 a 2 segundos
    sem_t * semSegInt = calle != 0 ? args->semX : args->semY; // semX o semY

    sem_wait(semSegInt);
    nombreInt = calle != 0 ? 'X' : 'Y';
    printf("Carro %d: Cruzando interseccion %c\n", id, nombreInt);
    sleep(1 + rand() % 1); // tiempo de espera interseccion, de 1 a 2 segundos
    sem_post(semSegInt);

    printf("Carro %d: Termine de cruzar calle %c.\n", id, calleNombre);
    exit(0);
}

int main(int argc, char ** argv) 
{
    sem_t recodoA;
    sem_t recodoB;
    sem_t semX;
    sem_t semY;

    int carrosRecodoA = 0;
    int carrosRecodoB = 0;

    sem_init(&recodoA, 1, 7); // 7 -> capacidad de los recodos
    sem_init(&recodoB, 1, 7);
    sem_init(&semX, 1, 1);
    sem_init(&semY, 1, 1);

    int carros = 4;
    if (argc == 2)
    {
        carros = atol(argv[1]);
    }

    key_t key = ftok("shmfile", 65);
    int sharedMemSize = sizeof(carroArgs);
    int shmid = shmget(key, sharedMemSize, 0777 | IPC_CREAT);

    carroArgs * cArgs = (carroArgs *) shmat(shmid, NULL, 0);

    cArgs->recodoA = &recodoA;
    cArgs->recodoB = &recodoB;
    cArgs->semX = &semX;
    cArgs->semY = &semY;

    cArgs->carrosRecodoA = &carrosRecodoA;
    cArgs->carrosRecodoB = &carrosRecodoB;

    printf("Creando %d carros.\n", carros);
    for(int i = 1; i <= carros; i++)
    {
        int pid = fork();
        int calle = i % 2 != 0 ? 0 : 1; // 0 -> calle a, 1 -> calle b
        if (pid == 0) // hijo - carro
        {
            rutinaCarro(i, calle, cArgs);
            break;
        }
        else {
            char nombreCalle = calle == 0 ? 'A' : 'B';
            printf("Creado carro %d en calle %c\n", i, nombreCalle);
        }
    }

    for (int carro = 0; carro < carros; carro++) 
    {
      int status;
      pid_t pid = wait( &status );
    }


    shmdt(cArgs);
    shmctl(shmid, IPC_RMID, NULL);
    return 0;

}