Para ejercicio b
ejecutar:
g++ -o ejb mainb.c -lpthread -lrt
correr:
/.ejb "numero de carros"
ej: ./ejb 20