#include <stdio.h> 
#include <pthread.h> 
#include <semaphore.h> 
#include <unistd.h> 
#include <stdlib.h>
#include <time.h>  
#include "monitor.h"

int KP = 3; 
int NP = 5; // calles
int cola = 0;

struct mArgs
{
    Monitor * monitor;
};

void * mControlador(void * arg)
{
    printf("Controlador creado");
}

void * mCarro(void * arg)
{
    mArgs * args = (mArgs *) arg;

    int micalle = rand() % NP;
    args->monitor->NuevoCarro(micalle);

    printf("Carro creado en calle %d\n", micalle);
}

int main(int argc, char ** argv)
{
    printf("Ejercicio C\n");
    printf("K = %d N = %d\n\n", KP, NP);

    Monitor m(NP, KP);

    int carros = 4;
    if (argc == 2)
    {
        carros = atol(argv[1]);
    }

    mArgs margs_t;
    margs_t.monitor = &m;


    pthread_t controlador;
    pthread_create(&controlador, NULL, mControlador, &margs_t);

    for(int i = 0; i < carros; i++)
    {
        pthread_t carro;
        pthread_create(&carro, NULL, mCarro, &margs_t);
    }

}